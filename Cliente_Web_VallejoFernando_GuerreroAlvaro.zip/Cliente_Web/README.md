cliente_Web_para_API_REST

Cliente Web en Javascript combinando: Knockout.js, jQuery, HTML5 y CSS para hacer peticiones a la API REST del servicio de Gestión 
de Usuarios que desplegamos en una receta anterior (https://mamiot.com/diseno-y-desarrollo-de-una-api-rest-en-python/).

